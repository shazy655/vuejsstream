<ul>
    <router-link  to='/' tag="li" exact routerLinkActive="active"><a>Home</a></router-link>
    <router-link to='/about' tag="li" exact ><a>About</a></router-link>
</ul>